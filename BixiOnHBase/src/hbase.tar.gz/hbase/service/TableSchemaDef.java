package hbase.service;

public class TableSchemaDef {
	
	public static String schema1_table_name = "BixiData";
	public static String SCHEMA1_FAMILY_NAME = "Data";  
	
	public static String SCHEMA3_CLUSTER_TABLE_NAME = "schema3_cluster";
	public static String SCHEMA3_CLUSTER_FAMILY_NAME = "s";
	public static String SCHEMA3_BIKE_TABLE_NAME = "schema3_bike";
	public static String SCHEMA3_BIKE_FAMILY_NAME = "t";
	
	

}
