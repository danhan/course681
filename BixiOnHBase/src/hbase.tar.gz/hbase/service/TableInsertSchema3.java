package hbase.service;

public class TableInsertSchema3 {

}
